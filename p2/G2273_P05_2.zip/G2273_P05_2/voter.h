/**
 * @file voter.h
 * @author Luis Miguel Nucifora & Alexis Canales Molina.
 * @brief Program that controls the voters access to files.
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <semaphore.h>
#include <fcntl.h>
#include <math.h>