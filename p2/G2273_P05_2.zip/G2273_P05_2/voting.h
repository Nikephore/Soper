/**
 * @file voting.h
 * @author Luis Miguel Nucifora & Alexis Canales Molina.
 * @brief Main program that monitors the voters.
 *
 * @copyright Copyright (c) 2023
 *
 */

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <semaphore.h>
#include <fcntl.h>
#include <math.h>

#include "voter.h"
#include "pow.h"

typedef struct
{
  pid_t voter_pid; /* pid del votante */
  int vote; /* Voto al proceso candidato 1=Y 0=N */
} voter;

/**
 * @brief The different voters compete to be the candidate, then vote and repeat if didnt receive a signal
 * @param sact      Pointer to the sigaction structure.
 * @param sem_c     Semaphore to decide the candidates.
 * @param sem_f     Semaphore to access files.
 * @param sem_s     Semaphore for signals.
 * @param n_procs   Number of processes.
 * @return EXIT_SUCCESS or EXIT_FAILURE
 */
void voter_process(struct sigaction sact, sem_t *sem_c, sem_t *sem_f, sem_t *sem_s, int n_procs);