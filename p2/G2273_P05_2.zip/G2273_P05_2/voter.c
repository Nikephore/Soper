/**
 * @file voter.c
 * @author Luis Miguel Nucifora & Alexis Canales Molina.
 * @brief Program that controls the voters access to files.
 *
 * @copyright Copyright (c) 2023
 *
 */

#include "voter.h"


